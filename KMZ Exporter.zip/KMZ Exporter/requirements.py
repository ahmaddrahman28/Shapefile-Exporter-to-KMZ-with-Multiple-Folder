"""
Dependencies checker for KMZ Exporter plugin
"""

import subprocess
import sys
import os

def install_simplekml():
    """Install simplekml library"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "simplekml"])
        return True
    except Exception as e:
        print(f"Failed to install simplekml: {e}")
        return False

def check_dependencies():
    """Check if all dependencies are installed"""
    try:
        import simplekml
        return True
    except ImportError:
        return False