# -*- coding: utf-8 -*-
"""
Resource file for KMZ Exporter plugin
"""
# Import the PyQt and QGIS libraries
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QCoreApplication
import os

def classFactory(iface):
    from .kmz_exporter import KMZExporterPlugin
    return KMZExporterPlugin(iface)