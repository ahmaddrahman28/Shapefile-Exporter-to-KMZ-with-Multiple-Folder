"""
KMZ Exporter Plugin for QGIS 3.x
Exports vector layers to KMZ format with advanced features
Supports polygons with holes (inner rings)
"""

import os
import tempfile
import traceback
import sys
from qgis.PyQt.QtCore import QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon, QColor, QPixmap
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QProgressDialog
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
    QgsRenderContext, QgsExpression, QgsExpressionContext,
    QgsExpressionContextUtils, QgsMapSettings,
    QgsPointXY, QgsSingleSymbolRenderer,
    QgsCategorizedSymbolRenderer, QgsGraduatedSymbolRenderer,
    QgsFeature
)

# Coba import simplekml
try:
    import simplekml
    SIMPLEKML_AVAILABLE = True
except ImportError:
    SIMPLEKML_AVAILABLE = False
    print("simplekml library not found. Please install it using: pip install simplekml")

from .export_dialog import ExportDialog


class KMZExporterPlugin:
    """Main plugin class for KMZ Exporter"""
    
    def __init__(self, iface):
        """Constructor"""
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.menu = '&KMZ Exporter'
        
        # Configuration
        self.line_width_factor = 2.0
        self.temp_dir = tempfile.gettempdir()
        self.png_icons = []
        
        # Style caching
        self.cat_styles = {}
        self.simple_style = None
        self.default_cat_index = -1
        
        # Render context
        self.symcontext = None
        self.field_exp = None
        self.exp_context = None
        self.render = None
        
        # Progress dialog
        self.progress = None

    def tr(self, message):
        """Get translation for a string"""
        return QCoreApplication.translate('KMZExporter', message)

    def initGui(self):
        """Initialize the GUI"""
        try:
            # Check for simplekml
            if not SIMPLEKML_AVAILABLE:
                icon = QIcon()
                self.action = QAction(icon, "KMZ Exporter (simplekml required)", self.iface.mainWindow())
                self.action.setWhatsThis("simplekml library required. Install using: pip install simplekml")
                self.action.setStatusTip("simplekml library required")
                self.action.triggered.connect(self.show_install_instructions)
            else:
                # Create icon
                icon_path = os.path.join(self.plugin_dir, 'icon.png')
                if os.path.exists(icon_path):
                    icon = QIcon(icon_path)
                else:
                    icon = QIcon()
                
                # Create action
                self.action = QAction(icon, "Export to KMZ", self.iface.mainWindow())
                self.action.setObjectName("kmzExporterAction")
                self.action.setWhatsThis("Export vector layer to KMZ format")
                self.action.setStatusTip("Export vector layer to KMZ format")
                self.action.triggered.connect(self.run)
            
            # Add to menu and toolbar
            self.iface.addPluginToMenu(self.menu, self.action)
            self.iface.addToolBarIcon(self.action)
            
            print("KMZ Exporter plugin loaded successfully")
            
        except Exception as e:
            print(f"Error loading KMZ Exporter plugin: {str(e)}")
            traceback.print_exc()

    def show_install_instructions(self):
        """Show installation instructions for simplekml"""
        QMessageBox.information(
            self.iface.mainWindow(),
            "Install simplekml",
            "The 'simplekml' library is required for this plugin.\n\n"
            "To install:\n"
            "1. Open OSGeo4W Shell (Windows) or Terminal (Linux/Mac)\n"
            "2. Run: pip install simplekml\n\n"
            "Or use QGIS Python console:\n"
            "import sys; import subprocess; subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'simplekml'])"
        )

    def unload(self):
        """Remove plugin from QGIS"""
        try:
            # Remove from menu
            self.iface.removePluginMenu(self.menu, self.action)
            
            # Remove from toolbar
            self.iface.removeToolBarIcon(self.action)
            
            # Clean up action
            if self.action:
                self.action.deleteLater()
                self.action = None
                
            print("KMZ Exporter plugin unloaded successfully")
            
        except Exception as e:
            print(f"Error unloading KMZ Exporter plugin: {str(e)}")
        
        self.cleanup()

    def cleanup(self):
        """Clean up temporary files"""
        for icon in self.png_icons:
            if os.path.exists(icon):
                try:
                    os.remove(icon)
                except:
                    pass

    def run(self):
        """Main run method"""
        if not SIMPLEKML_AVAILABLE:
            self.show_install_instructions()
            return
            
        # Get active layer
        layer = self.iface.activeLayer()
        
        if not layer:
            QMessageBox.warning(
                self.iface.mainWindow(),
                self.tr('Warning'),
                self.tr('Please select a vector layer first!')
            )
            return
            
        if not isinstance(layer, QgsVectorLayer):
            QMessageBox.warning(
                self.iface.mainWindow(),
                self.tr('Warning'),
                self.tr('Selected layer is not a vector layer!')
            )
            return

        # Show export dialog
        dlg = ExportDialog(layer, self.iface.mainWindow())
        if dlg.exec_():
            try:
                self.export_kmz(dlg.get_parameters())
            except Exception as e:
                QMessageBox.critical(
                    self.iface.mainWindow(),
                    self.tr('Error'),
                    self.tr('Failed to export KMZ: {}').format(str(e))
                )
                traceback.print_exc()

    def qcolor_to_kml_color(self, color, opacity=1.0):
        """Convert QColor to KML color format (AABBGGRR)"""
        if not color or not color.isValid():
            return "ffffffff"
        
        # Calculate alpha
        alpha = int((color.alpha() / 255.0) * opacity * 255.0)
        alpha = max(0, min(255, alpha))
        
        # KML format: AA BB GG RR
        return f"{alpha:02x}{color.blue():02x}{color.green():02x}{color.red():02x}"

    def init_styles(self, layer, geometry_type):
        """Initialize styles from QGIS layer"""
        self.cat_styles = {}
        self.simple_style = None
        self.default_cat_index = -1
        
        try:
            self.render = layer.renderer()
            self.exp_context = QgsExpressionContext()
            self.exp_context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
            
            # Setup render context
            if self.symcontext is None:
                map_settings = self.iface.mapCanvas().mapSettings()
                self.symcontext = QgsRenderContext.fromMapSettings(map_settings)
            
        except Exception as e:
            print(f"Cannot determine layer style: {e}")
            return
        
        render_type = self.render.type()
        layer_opacity = layer.opacity() if hasattr(layer, 'opacity') else 1.0
        
        if render_type == 'singleSymbol':
            symbol = self.render.symbol()
            symbol_opacity = symbol.opacity() if hasattr(symbol, 'opacity') else 1.0
            combined_opacity = layer_opacity * symbol_opacity
            
            self.simple_style = simplekml.Style()
            
            if geometry_type == QgsWkbTypes.PointGeometry:
                sym_size = symbol.size(self.symcontext)
                color = symbol.color()
                self.simple_style.iconstyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                self.simple_style.iconstyle.scale = max(0.5, sym_size / 10)
                self.simple_style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png'
                
            elif geometry_type == QgsWkbTypes.LineGeometry:
                symbol_width = symbol.width()
                if symbol_width == 0:
                    symbol_width = 0.5
                
                color = symbol.color()
                self.simple_style.linestyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                self.simple_style.linestyle.width = symbol_width * self.line_width_factor
                
            elif geometry_type == QgsWkbTypes.PolygonGeometry:
                if symbol.symbolLayerCount() > 0:
                    symbol_layer = symbol.symbolLayer(0)
                    layer_type = symbol_layer.layerType()
                    
                    if layer_type == 'SimpleFill':
                        stroke_style = symbol_layer.strokeStyle()
                        if stroke_style == 0:
                            stroke_width = 0
                        else:
                            stroke_width = symbol_layer.strokeWidth()
                        
                        stroke_color = symbol_layer.strokeColor()
                        fill_color = symbol_layer.color()
                        
                        self.simple_style.linestyle.color = self.qcolor_to_kml_color(stroke_color, combined_opacity)
                        self.simple_style.linestyle.width = stroke_width * self.line_width_factor
                        self.simple_style.polystyle.color = self.qcolor_to_kml_color(fill_color, combined_opacity)
                        self.simple_style.polystyle.fill = 1
                        self.simple_style.polystyle.outline = 1
                        
                    elif layer_type == 'SimpleLine':
                        stroke_width = symbol_layer.width()
                        color = symbol_layer.color()
                        
                        self.simple_style.linestyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                        self.simple_style.linestyle.width = stroke_width * self.line_width_factor
                        self.simple_style.polystyle.color = '00ffffff'
                        
                    else:
                        stroke_width = 0.5
                        self.simple_style.linestyle.color = 'ff000000'
                        self.simple_style.linestyle.width = stroke_width * self.line_width_factor
                        self.simple_style.polystyle.color = 'ffffffff'
        
        elif render_type == 'categorizedSymbol':
            style_field = self.render.classAttribute()
            self.field_exp = QgsExpression('"{}"'.format(style_field))
            
            for idx, category in enumerate(self.render.categories()):
                cat_style = simplekml.Style()
                symbol = category.symbol()
                symbol_opacity = symbol.opacity() if hasattr(symbol, 'opacity') else 1.0
                combined_opacity = layer_opacity * symbol_opacity
                
                if not category.value():
                    self.default_cat_index = idx
                
                if geometry_type == QgsWkbTypes.PointGeometry:
                    sym_size = symbol.size(self.symcontext)
                    color = symbol.color()
                    cat_style.iconstyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                    cat_style.iconstyle.scale = max(0.5, sym_size / 10)
                    cat_style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png'
                    
                elif geometry_type == QgsWkbTypes.LineGeometry:
                    symbol_width = symbol.width()
                    if symbol_width == 0:
                        symbol_width = 0.5
                    
                    color = symbol.color()
                    cat_style.linestyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                    cat_style.linestyle.width = symbol_width * self.line_width_factor
                    
                elif geometry_type == QgsWkbTypes.PolygonGeometry:
                    if symbol.symbolLayerCount() > 0:
                        symbol_layer = symbol.symbolLayer(0)
                        layer_type = symbol_layer.layerType()
                        
                        if layer_type == 'SimpleFill':
                            stroke_style = symbol_layer.strokeStyle()
                            if stroke_style == 0:
                                stroke_width = 0
                            else:
                                stroke_width = symbol_layer.strokeWidth()
                            
                            stroke_color = symbol_layer.strokeColor()
                            fill_color = symbol_layer.color()
                            
                            cat_style.linestyle.color = self.qcolor_to_kml_color(stroke_color, combined_opacity)
                            cat_style.linestyle.width = stroke_width * self.line_width_factor
                            cat_style.polystyle.color = self.qcolor_to_kml_color(fill_color, combined_opacity)
                            cat_style.polystyle.fill = 1
                            cat_style.polystyle.outline = 1
                            
                        elif layer_type == 'SimpleLine':
                            stroke_width = symbol_layer.width()
                            color = symbol_layer.color()
                            
                            cat_style.linestyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                            cat_style.linestyle.width = stroke_width * self.line_width_factor
                            cat_style.polystyle.color = '00ffffff'
                            
                        else:
                            stroke_width = 0.5
                            cat_style.linestyle.color = 'ff000000'
                            cat_style.linestyle.width = stroke_width * self.line_width_factor
                            cat_style.polystyle.color = 'ffffffff'
                
                self.cat_styles[idx] = cat_style
        
        elif render_type == 'graduatedSymbol':
            style_field = self.render.classAttribute()
            self.field_exp = QgsExpression(style_field)
            
            for idx, rng in enumerate(self.render.ranges()):
                cat_style = simplekml.Style()
                symbol = rng.symbol()
                symbol_opacity = symbol.opacity() if hasattr(symbol, 'opacity') else 1.0
                combined_opacity = layer_opacity * symbol_opacity
                
                if geometry_type == QgsWkbTypes.PointGeometry:
                    sym_size = symbol.size(self.symcontext)
                    color = symbol.color()
                    cat_style.iconstyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                    cat_style.iconstyle.scale = max(0.5, sym_size / 10)
                    cat_style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png'
                    
                elif geometry_type == QgsWkbTypes.LineGeometry:
                    symbol_width = symbol.width()
                    if symbol_width == 0:
                        symbol_width = 0.5
                    
                    color = symbol.color()
                    cat_style.linestyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                    cat_style.linestyle.width = symbol_width * self.line_width_factor
                    
                elif geometry_type == QgsWkbTypes.PolygonGeometry:
                    if symbol.symbolLayerCount() > 0:
                        symbol_layer = symbol.symbolLayer(0)
                        layer_type = symbol_layer.layerType()
                        
                        if layer_type == 'SimpleFill':
                            stroke_style = symbol_layer.strokeStyle()
                            if stroke_style == 0:
                                sym_size = 0
                            else:
                                sym_size = symbol_layer.strokeWidth()
                            
                            stroke_color = symbol_layer.strokeColor()
                            fill_color = symbol_layer.color()
                            
                            cat_style.linestyle.color = self.qcolor_to_kml_color(stroke_color, combined_opacity)
                            cat_style.linestyle.width = sym_size * self.line_width_factor
                            cat_style.polystyle.color = self.qcolor_to_kml_color(fill_color, combined_opacity)
                            cat_style.polystyle.fill = 1
                            cat_style.polystyle.outline = 1
                            
                        elif layer_type == 'SimpleLine':
                            sym_size = symbol_layer.width()
                            color = symbol_layer.color()
                            
                            cat_style.linestyle.color = self.qcolor_to_kml_color(color, combined_opacity)
                            cat_style.linestyle.width = sym_size * self.line_width_factor
                            cat_style.polystyle.color = '00ffffff'
                            
                        else:
                            sym_size = 0.5
                            cat_style.linestyle.color = 'ff000000'
                            cat_style.linestyle.width = sym_size * self.line_width_factor
                            cat_style.polystyle.color = 'ffffffff'
                
                key = (sym_size, self.qcolor_to_kml_color(symbol.color(), combined_opacity))
                self.cat_styles[key] = cat_style

    def get_feature_style(self, feature, layer, geometry_type, use_layer_style=True,
                         custom_line_color=None, custom_stroke_width=2.0,
                         custom_fill_color=None):
        """Get style for a feature"""
        if not use_layer_style:
            style = simplekml.Style()
            if geometry_type == QgsWkbTypes.PointGeometry:
                style.iconstyle.color = self.qcolor_to_kml_color(custom_line_color)
                style.iconstyle.scale = 1.2
                style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png'
            elif geometry_type == QgsWkbTypes.LineGeometry:
                style.linestyle.color = self.qcolor_to_kml_color(custom_line_color)
                style.linestyle.width = custom_stroke_width * self.line_width_factor
            elif geometry_type == QgsWkbTypes.PolygonGeometry:
                style.linestyle.color = self.qcolor_to_kml_color(custom_line_color)
                style.linestyle.width = custom_stroke_width * self.line_width_factor
                style.polystyle.color = self.qcolor_to_kml_color(custom_fill_color)
                style.polystyle.fill = 1
                style.polystyle.outline = 1
            return style
        
        if not hasattr(self, 'render') or not self.render:
            return simplekml.Style()
        
        render_type = self.render.type()
        
        if render_type == 'singleSymbol':
            if self.simple_style:
                return self.simple_style
            
        elif render_type == 'categorizedSymbol':
            try:
                self.exp_context.setFeature(feature)
                value = self.field_exp.evaluate(self.exp_context)
                catindex = self.render.categoryIndexForValue(value)
                
                if catindex == -1 and self.default_cat_index != -1:
                    catindex = self.default_cat_index
                
                if catindex not in self.cat_styles:
                    catindex = 0
                
                if catindex in self.cat_styles:
                    return self.cat_styles[catindex]
                    
            except Exception as e:
                print(f"Error getting categorized style: {e}")
        
        elif render_type == 'graduatedSymbol':
            try:
                self.exp_context.setFeature(feature)
                value = self.field_exp.evaluate(self.exp_context)
                rng = self.render.rangeForValue(value)
                
                if rng is None:
                    return simplekml.Style()
                
                symbol = rng.symbol()
                layer_opacity = layer.opacity() if hasattr(layer, 'opacity') else 1.0
                opacity = symbol.opacity() * layer_opacity
                
                if geometry_type == QgsWkbTypes.PointGeometry:
                    sym_size = symbol.size(self.symcontext)
                    color = self.qcolor_to_kml_color(symbol.color(), opacity)
                elif geometry_type == QgsWkbTypes.LineGeometry:
                    sym_size = symbol.width()
                    if sym_size == 0:
                        sym_size = 0.5
                    color = self.qcolor_to_kml_color(symbol.color(), opacity)
                else:
                    symbol_layer = symbol.symbolLayer(0)
                    stroke_style = symbol_layer.strokeStyle()
                    if stroke_style == 0:
                        sym_size = 0
                    else:
                        sym_size = symbol_layer.strokeWidth()
                    color = self.qcolor_to_kml_color(symbol_layer.color(), opacity)
                
                key = (sym_size, color)
                if key in self.cat_styles:
                    return self.cat_styles[key]
                    
            except Exception as e:
                print(f"Error getting graduated style: {e}")
        
        # Fallback style
        style = simplekml.Style()
        try:
            context = QgsRenderContext()
            symbol = self.render.symbolForFeature(feature, context)
            if not symbol:
                symbol = self.render.symbol()
            
            layer_opacity = layer.opacity() if hasattr(layer, 'opacity') else 1.0
            opacity = symbol.opacity() * layer_opacity
            
            if geometry_type == QgsWkbTypes.PointGeometry:
                color = symbol.color()
                style.iconstyle.color = self.qcolor_to_kml_color(color, opacity)
                style.iconstyle.scale = 1.0
                style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png'
                
            elif geometry_type == QgsWkbTypes.LineGeometry:
                symbol_width = symbol.width()
                if symbol_width == 0:
                    symbol_width = 0.5
                
                color = symbol.color()
                style.linestyle.color = self.qcolor_to_kml_color(color, opacity)
                style.linestyle.width = symbol_width * self.line_width_factor
                
            elif geometry_type == QgsWkbTypes.PolygonGeometry:
                if symbol.symbolLayerCount() > 0:
                    symbol_layer = symbol.symbolLayer(0)
                    layer_type = symbol_layer.layerType()
                    
                    if layer_type == 'SimpleFill':
                        stroke_style = symbol_layer.strokeStyle()
                        if stroke_style == 0:
                            stroke_width = 0
                        else:
                            stroke_width = symbol_layer.strokeWidth()
                        
                        stroke_color = symbol_layer.strokeColor()
                        fill_color = symbol_layer.color()
                        
                        style.linestyle.color = self.qcolor_to_kml_color(stroke_color, opacity)
                        style.linestyle.width = stroke_width * self.line_width_factor
                        style.polystyle.color = self.qcolor_to_kml_color(fill_color, opacity)
                        style.polystyle.fill = 1
                        style.polystyle.outline = 1
                        
                    elif layer_type == 'SimpleLine':
                        stroke_width = symbol_layer.width()
                        color = symbol_layer.color()
                        
                        style.linestyle.color = self.qcolor_to_kml_color(color, opacity)
                        style.linestyle.width = stroke_width * self.line_width_factor
                        style.polystyle.color = '00ffffff'
                        
        except Exception as e:
            print(f"Error creating fallback style: {e}")
        
        return style

    def transform_geometry_to_wgs84(self, geometry, source_crs):
        """Transform geometry to WGS84"""
        try:
            target_crs = QgsCoordinateReferenceSystem('EPSG:4326')
            if source_crs is None or source_crs.authid() != target_crs.authid():
                transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
                transformed_geometry = QgsGeometry(geometry)
                transformed_geometry.transform(transform)
                return transformed_geometry
            else:
                return QgsGeometry(geometry)
        except Exception as e:
            print(f"Error transforming geometry: {e}")
            return QgsGeometry(geometry)

    def group_features(self, features, parent_field, sub_field, sub_sub_field, label_field, skip_empty_folders):
        """Group features by folder structure"""
        tree = {}
        
        for feature in features:
            try:
                attrs = feature.attributes()
                field_names = [field.name() for field in feature.fields()]
                props = dict(zip(field_names, attrs))
            except Exception:
                props = {}

            def norm(v):
                if v is None:
                    return None
                s = str(v).strip()
                return s if s != "" else None

            p1 = norm(props.get(parent_field)) if parent_field else None
            p2 = norm(props.get(sub_field)) if sub_field else None
            p3 = norm(props.get(sub_sub_field)) if sub_sub_field else None

            if skip_empty_folders and not any([p1, p2, p3]):
                path = []
            else:
                path = []
                if p1:
                    path.append(p1)
                if p2:
                    path.append(p2)
                if p3:
                    path.append(p3)

            node = tree
            for key in path:
                node = node.setdefault(key, {})
            node.setdefault("_features_", []).append({
                "properties": props,
                "geometry": feature.geometry(),
                "feature": feature
            })

        return tree

    def create_description(self, props, selected_fields):
        """Create HTML description for KML placemark"""
        if not selected_fields:
            return ""
        
        rows = []
        for i, field_name in enumerate(selected_fields):
            if field_name in props:
                value = props[field_name]
                if value is None:
                    value = ""
                bg = "#DDDDFF" if i % 2 == 0 else "transparent"
                safe_value = str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                safe_field = str(field_name).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                rows.append(f'<tr style="background-color:{bg};"><td><b>{safe_field}</b></td><td>{safe_value}</td></tr>')
        
        if not rows:
            return ""
        
        html = f"""<![CDATA[
        <html>
        <body>
        <table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; font-size: 11px;">
        {''.join(rows)}
        </table>
        </body>
        </html>
        ]]>"""
        
        return html

    def export_kmz(self, params):
        """Main export function"""
        try:
            # Get parameters
            layer = params['layer']
            output_kmz = params['output_file']
            parent_field = params['parent_field']
            sub_field = params['sub_field']
            sub_sub_field = params['sub_sub_field']
            label_field = params['label_field']
            skip_empty_folders = params['skip_empty_folders']
            selected_fields = params['selected_fields']
            use_layer_style = params['use_layer_style']
            
            custom_line_color = params.get('custom_line_color', QColor(0, 0, 255))
            custom_stroke_width = params.get('custom_stroke_width', 2.0)
            custom_fill_color = params.get('custom_fill_color', QColor(255, 0, 0, 102))

            # Validate output file
            if not output_kmz:
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    self.tr('Warning'),
                    self.tr('Please specify output file path!')
                )
                return

            # Add .kmz extension if not present
            if not output_kmz.lower().endswith('.kmz'):
                output_kmz += '.kmz'

            # Check output directory
            output_dir = os.path.dirname(output_kmz)
            if output_dir and not os.path.exists(output_dir):
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    self.tr('Warning'),
                    self.tr('Output directory does not exist!')
                )
                return

            # Get features
            features = list(layer.getFeatures())
            if not features:
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    self.tr('Warning'),
                    self.tr('No features found in the selected layer!')
                )
                return

            # Create progress dialog
            self.progress = QProgressDialog(
                self.tr("Exporting to KMZ..."),
                self.tr("Cancel"),
                0,
                len(features),
                self.iface.mainWindow()
            )
            self.progress.setWindowTitle(self.tr("KMZ Export"))
            self.progress.setWindowModality(Qt.WindowModal)
            self.progress.show()

            # Create KML
            kml = simplekml.Kml()
            kml.document.name = os.path.splitext(os.path.basename(output_kmz))[0]
            kml.document.description = f"Exported from QGIS layer: {layer.name()}"

            # Initialize styles
            geometry_type = layer.geometryType()
            self.init_styles(layer, geometry_type)

            # Group features
            grouped = self.group_features(features, parent_field, sub_field, sub_sub_field, 
                                        label_field, skip_empty_folders)

            # Process features
            processed_count = 0
            failed_count = 0
            
            def process_node(node, parent_folder=None, depth=0):
                nonlocal processed_count, failed_count
                
                # Process features in this node
                for feature_data in node.get("_features_", []):
                    if self.progress.wasCanceled():
                        return False
                    
                    try:
                        feature = feature_data["feature"]
                        geom = feature_data["geometry"]
                        props = feature_data["properties"]
                        
                        # Transform geometry
                        transformed_geom = self.transform_geometry_to_wgs84(geom, layer.crs())
                        if not transformed_geom or transformed_geom.isEmpty():
                            failed_count += 1
                            continue
                        
                        # Get feature name
                        name = str(props.get(label_field, "")) if label_field else "Feature"
                        if not name or name == "NULL":
                            name = f"Feature {processed_count + 1}"
                        
                        # Create description
                        description = self.create_description(props, selected_fields)
                        
                        # Get style
                        style = self.get_feature_style(feature, layer, geometry_type, use_layer_style,
                                                     custom_line_color, custom_stroke_width,
                                                     custom_fill_color)
                        
                        # Create placemark
                        placemark = None
                        geom_type = transformed_geom.type()
                        
                        if geom_type == QgsWkbTypes.PointGeometry:
                            placemark = self.create_kml_point(kml, transformed_geom, name, description, parent_folder)
                        elif geom_type == QgsWkbTypes.LineGeometry:
                            placemark = self.create_kml_line(kml, transformed_geom, name, description, parent_folder)
                        elif geom_type == QgsWkbTypes.PolygonGeometry:
                            placemark = self.create_kml_polygon_with_holes(kml, transformed_geom, name, description, parent_folder)
                        
                        if placemark and style:
                            placemark.style = style
                        
                        processed_count += 1
                        self.progress.setValue(processed_count)
                        
                    except Exception as e:
                        print(f"Error processing feature: {e}")
                        traceback.print_exc()
                        failed_count += 1
                        continue
                
                # Process sub-folders
                for key in sorted(k for k in node.keys() if k != "_features_"):
                    if self.progress.wasCanceled():
                        return False
                    
                    child_node = node[key]
                    folder_name = str(key) if key else "Unnamed"
                    
                    # Create folder
                    if parent_folder:
                        new_folder = parent_folder.newfolder(name=folder_name)
                    else:
                        new_folder = kml.newfolder(name=folder_name)
                    
                    # Process recursively
                    if not process_node(child_node, new_folder, depth + 1):
                        return False
                
                return True
            
            # Start processing
            if not process_node(grouped, None):
                if self.progress.wasCanceled():
                    QMessageBox.information(
                        self.iface.mainWindow(),
                        self.tr('Export Canceled'),
                        self.tr('Export was canceled by user.')
                    )
                    return
            
            # Close progress dialog
            self.progress.close()
            
            # Save KMZ
            try:
                kml.savekmz(output_kmz)
            except Exception as e:
                # Fallback: save as KML
                try:
                    kml_path = output_kmz.replace('.kmz', '.kml')
                    kml.save(kml_path)
                    QMessageBox.warning(
                        self.iface.mainWindow(),
                        self.tr('Partial Success'),
                        self.tr('Saved as KML instead of KMZ: {}\nError: {}').format(kml_path, str(e))
                    )
                    return
                except Exception as e2:
                    raise e2
            
            self.cleanup()
            
            # Show result message
            message = self.tr('KMZ file created successfully: {}').format(output_kmz)
            if failed_count > 0:
                message += f"\n{self.tr('Note: {0} features failed to export.').format(failed_count)}"
            
            QMessageBox.information(
                self.iface.mainWindow(),
                self.tr('Success'),
                message
            )

        except Exception as e:
            if self.progress:
                self.progress.close()
            
            QMessageBox.critical(
                self.iface.mainWindow(),
                self.tr('Error'),
                self.tr('Failed to create KMZ: {}').format(str(e))
            )
            print(f"Error details: {str(e)}")
            traceback.print_exc()

    def create_kml_point(self, kml, geometry, name, description, parent_folder=None):
        """Create KML point placemark"""
        try:
            if geometry.isMultipart():
                points = geometry.asMultiPoint()
                if points:
                    if parent_folder:
                        multi = parent_folder.newmultigeometry(name=name)
                    else:
                        multi = kml.newmultigeometry(name=name)
                    multi.description = description
                    for point in points:
                        multi.newpoint(coords=[(point.x(), point.y())])
                    return multi
            else:
                point = geometry.asPoint()
                if parent_folder:
                    placemark = parent_folder.newpoint(name=name, coords=[(point.x(), point.y())])
                else:
                    placemark = kml.newpoint(name=name, coords=[(point.x(), point.y())])
                placemark.description = description
                return placemark
        except Exception as e:
            print(f"Error creating KML point: {e}")
            return None

    def create_kml_line(self, kml, geometry, name, description, parent_folder=None):
        """Create KML line placemark"""
        try:
            if geometry.isMultipart():
                lines = geometry.asMultiPolyline()
                if lines:
                    if parent_folder:
                        multi = parent_folder.newmultigeometry(name=name)
                    else:
                        multi = kml.newmultigeometry(name=name)
                    multi.description = description
                    for line in lines:
                        if len(line) >= 2:
                            multi.newlinestring(coords=[(pt.x(), pt.y()) for pt in line])
                    return multi
            else:
                line = geometry.asPolyline()
                if len(line) >= 2:
                    if parent_folder:
                        placemark = parent_folder.newlinestring(name=name, coords=[(pt.x(), pt.y()) for pt in line])
                    else:
                        placemark = kml.newlinestring(name=name, coords=[(pt.x(), pt.y()) for pt in line])
                    placemark.description = description
                    return placemark
        except Exception as e:
            print(f"Error creating KML line: {e}")
            return None

    def create_kml_polygon_with_holes(self, kml, geometry, name, description, parent_folder=None):
        """Create KML polygon placemark with support for holes (inner rings)"""
        try:
            if geometry.isMultipart():
                # Handle multipart polygons
                polygons = geometry.asMultiPolygon()
                if polygons:
                    if parent_folder:
                        multi = parent_folder.newmultigeometry(name=name)
                    else:
                        multi = kml.newmultigeometry(name=name)
                    multi.description = description
                    
                    for polygon in polygons:
                        if polygon and len(polygon) > 0:
                            kml_poly = multi.newpolygon()
                            self._add_polygon_rings_with_holes(kml_poly, polygon)
                    return multi
            else:
                # Handle single polygon
                polygon = geometry.asPolygon()
                if polygon and len(polygon) > 0:
                    if parent_folder:
                        placemark = parent_folder.newpolygon(name=name)
                    else:
                        placemark = kml.newpolygon(name=name)
                    placemark.description = description
                    self._add_polygon_rings_with_holes(placemark, polygon)
                    return placemark
        except Exception as e:
            print(f"Error creating KML polygon with holes: {e}")
            traceback.print_exc()
        return None

    def _add_polygon_rings_with_holes(self, kml_polygon, polygon_rings):
        """
        Add outer and inner rings to KML polygon with proper hole handling
        
        Args:
            kml_polygon: simplekml.Polygon object
            polygon_rings: List of rings from QgsGeometry.asPolygon()
                          First ring is outer boundary, subsequent rings are holes
        """
        if not polygon_rings or len(polygon_rings) == 0:
            return
        
        # Debug info
        print(f"Processing polygon with {len(polygon_rings)} rings")
        
        # Outer ring (first ring) - boundary
        outer_ring = polygon_rings[0]
        if len(outer_ring) < 3:
            print("Warning: Outer ring has less than 3 points")
            return
        
        # Ensure polygon is closed (first point = last point)
        if outer_ring[0] != outer_ring[-1]:
            outer_ring.append(outer_ring[0])
        
        # Convert to KML coordinates (longitude, latitude)
        outer_coords = [(pt.x(), pt.y()) for pt in outer_ring]
        kml_polygon.outerboundaryis = outer_coords
        
        # Inner rings (holes) - start from second ring
        if len(polygon_rings) > 1:
            inner_boundaries = []
            
            for i, inner_ring in enumerate(polygon_rings[1:]):
                if len(inner_ring) < 3:
                    print(f"Warning: Inner ring {i} has less than 3 points, skipping")
                    continue
                
                # Ensure inner ring is closed
                if inner_ring[0] != inner_ring[-1]:
                    inner_ring.append(inner_ring[0])
                
                # Check if inner ring is inside outer ring (basic check)
                if self._is_ring_inside_ring(inner_ring, outer_ring):
                    # Convert to KML coordinates
                    inner_coords = [(pt.x(), pt.y()) for pt in inner_ring]
                    inner_boundaries.append(inner_coords)
                else:
                    print(f"Warning: Inner ring {i} appears to be outside outer ring")
            
            if inner_boundaries:
                kml_polygon.innerboundaryis = inner_boundaries
        
        print(f"Added polygon with {len(outer_coords)} outer points and {len(kml_polygon.innerboundaryis) if hasattr(kml_polygon, 'innerboundaryis') else 0} inner rings")

    def _is_ring_inside_ring(self, inner_ring, outer_ring):
        """
        Check if inner ring is inside outer ring using point-in-polygon test
        Simple check: test first point of inner ring
        """
        if not inner_ring or not outer_ring:
            return False
        
        test_point = inner_ring[0]
        return self._point_in_polygon(test_point, outer_ring)

    def _point_in_polygon(self, point, polygon):
        """
        Ray casting algorithm to check if point is inside polygon
        Returns True if point is inside polygon, False otherwise
        """
        x, y = point.x(), point.y()
        n = len(polygon)
        inside = False
        
        p1x, p1y = polygon[0].x(), polygon[0].y()
        for i in range(1, n + 1):
            p2x, p2y = polygon[i % n].x(), polygon[i % n].y()
            
            # Check if point is on horizontal edge
            if y > min(p1y, p2y):
                if y <= max(p1y, p2y):
                    if x <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                        if p1x == p2x or x <= xinters:
                            inside = not inside
            p1x, p1y = p2x, p2y
        
        return inside

    # Keep old method for backward compatibility
    def create_kml_polygon(self, kml, geometry, name, description, parent_folder=None):
        """Legacy method - uses new method with hole support"""
        return self.create_kml_polygon_with_holes(kml, geometry, name, description, parent_folder)

    # Keep old method for backward compatibility
    def _add_polygon_rings(self, kml_polygon, polygon_rings):
        """Legacy method - uses new method with hole support"""
        return self._add_polygon_rings_with_holes(kml_polygon, polygon_rings)