import os
import tempfile
import zipfile
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry
)

from .export_dialog import ExportDialog


class KMZExporterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr('KMZ Exporter')
        self.first_start = None

    def tr(self, message):
        return QCoreApplication.translate('KMZExporter', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True,
                   add_to_menu=True, add_to_toolbar=True, status_tip=None,
                   whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            try:
                self.iface.addToolBarIcon(action)
            except Exception:
                pass

        if add_to_menu:
            try:
                self.iface.addPluginToMenu(self.menu, action)
            except Exception:
                try:
                    self.iface.addPluginToMenu(self.menu, action)
                except Exception:
                    pass

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.add_action(
            icon_path,
            text=self.tr('Export to KMZ'),
            callback=self.run,
            parent=self.iface.mainWindow())

        self.first_start = True

    def unload(self):
        for action in self.actions:
            try:
                self.iface.removePluginMenu(self.tr('KMZ Exporter'), action)
                self.iface.removeToolBarIcon(action)
            except Exception:
                pass

    def run(self):
        if self.first_start:
            self.first_start = False

        layer = self.iface.activeLayer()
        if not layer or not isinstance(layer, QgsVectorLayer):
            QMessageBox.warning(
                self.iface.mainWindow(),
                self.tr('Warning'),
                self.tr('Please select a vector layer first!')
            )
            return

        dlg = ExportDialog(layer, self.iface.mainWindow())
        if dlg.exec_():
            self.export_kmz(dlg.get_parameters())

    def export_kmz(self, params):
        try:
            layer = params['layer']
            output_kmz = params['output_file']
            parent_field = params['parent_field']
            sub_field = params['sub_field']
            sub_sub_field = params['sub_sub_field']
            label_field = params['label_field']
            line_color = params['line_color']
            skip_empty_folders = params['skip_empty_folders']
            selected_fields = params['selected_fields']
            use_layer_style = params['use_layer_style']

            if not output_kmz:
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    self.tr('Warning'),
                    self.tr('Please specify output file path!')
                )
                return

            features = list(layer.getFeatures())
            if not features:
                QMessageBox.warning(
                    self.iface.mainWindow(),
                    self.tr('Warning'),
                    self.tr('No features found in the selected layer!')
                )
                return

            grouped = self.group_features(features, parent_field, sub_field, sub_sub_field, label_field, skip_empty_folders)

            kml_text = self.build_kml(grouped, os.path.basename(output_kmz), label_field, line_color, layer, selected_fields, use_layer_style)

            with tempfile.TemporaryDirectory() as tmp:
                kml_path = os.path.join(tmp, "doc.kml")
                with open(kml_path, "w", encoding="utf-8") as f:
                    f.write(kml_text)

                with zipfile.ZipFile(output_kmz, "w", compression=zipfile.ZIP_DEFLATED) as z:
                    z.write(kml_path, "doc.kml")

            QMessageBox.information(
                self.iface.mainWindow(),
                self.tr('Success'),
                self.tr('KMZ file created successfully: {}').format(output_kmz)
            )

        except Exception as e:
            QMessageBox.critical(
                self.iface.mainWindow(),
                self.tr('Error'),
                self.tr('Failed to create KMZ: {}').format(str(e))
            )

    def safe(self, x):
        if x is None:
            return ""
        return str(x).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def transform_geometry_to_wgs84(self, geometry, source_crs):
        try:
            target_crs = QgsCoordinateReferenceSystem('EPSG:4326')
            if source_crs is None or source_crs.authid() != target_crs.authid():
                transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
                transformed_geometry = QgsGeometry(geometry)
                transformed_geometry.transform(transform)
                return transformed_geometry
            else:
                return QgsGeometry(geometry)
        except Exception as e:
            print(f"Error transforming geometry: {e}")
            return QgsGeometry(geometry)

    def get_layer_style_color(self, layer, feature):
        try:
            renderer = layer.renderer()
            if not renderer:
                return None

            try:
                symbol = renderer.symbolForFeature(feature)
            except Exception:
                symbol = None

            if symbol:
                color = symbol.color()
                if color:
                    return f"{color.alpha():02x}{color.blue():02x}{color.green():02x}{color.red():02x}"
            return None
        except Exception as e:
            print(f"Error getting layer style: {e}")
            return None

    def geom_to_kml_fragments(self, geometry):
        if not geometry or geometry.isEmpty():
            return []

        try:
            geom_type = geometry.type()
            wkb_type = geometry.wkbType()
            fragments = []

            if geom_type == QgsWkbTypes.PointGeometry:
                try:
                    p = geometry.asPoint()
                    fragments.append(f"<Point><coordinates>{p.x()},{p.y()},0</coordinates></Point>")
                except Exception:
                    for p in geometry.asMultiPoint():
                        fragments.append(f"<Point><coordinates>{p.x()},{p.y()},0</coordinates></Point>")

            elif geom_type == QgsWkbTypes.LineGeometry:
                try:
                    pts = geometry.asPolyline()
                    if pts and len(pts) > 0:
                        coords = " ".join([f"{pt.x()},{pt.y()},0" for pt in pts])
                        fragments.append(f"<LineString><coordinates>{coords}</coordinates></LineString>")
                    else:
                        for line in geometry.asMultiPolyline():
                            if line:
                                coords = " ".join([f"{pt.x()},{pt.y()},0" for pt in line])
                                fragments.append(f"<LineString><coordinates>{coords}</coordinates></LineString>")
                except Exception:
                    for line in geometry.asMultiPolyline():
                        if line:
                            coords = " ".join([f"{pt.x()},{pt.y()},0" for pt in line])
                            fragments.append(f"<LineString><coordinates>{coords}</coordinates></LineString>")

            elif geom_type == QgsWkbTypes.PolygonGeometry:
                try:
                    polys = geometry.asPolygon()
                    if polys:
                        for poly in polys:
                            if poly:
                                ring_coords = " ".join([f"{pt.x()},{pt.y()},0" for pt in poly])
                                outer = f"<outerBoundaryIs><LinearRing><coordinates>{ring_coords}</coordinates></LinearRing></outerBoundaryIs>"
                                fragments.append(f"<Polygon>{outer}</Polygon>")
                    else:
                        for mp in geometry.asMultiPolygon():
                            for poly in mp:
                                if poly:
                                    ring_coords = " ".join([f"{pt.x()},{pt.y()},0" for pt in poly])
                                    outer = f"<outerBoundaryIs><LinearRing><coordinates>{ring_coords}</coordinates></LinearRing></outerBoundaryIs>"
                                    fragments.append(f"<Polygon>{outer}</Polygon>")
                except Exception:
                    for mp in geometry.asMultiPolygon():
                        for poly in mp:
                            if poly:
                                ring_coords = " ".join([f"{pt.x()},{pt.y()},0" for pt in poly])
                                outer = f"<outerBoundaryIs><LinearRing><coordinates>{ring_coords}</coordinates></LinearRing></outerBoundaryIs>"
                                fragments.append(f"<Polygon>{outer}</Polygon>")

            return fragments

        except Exception as e:
            print(f"Error processing geometry: {e}")
            return []

    def group_features(self, features, parent_field, sub_field, sub_sub_field, label_field, skip_empty_folders):
        tree = {}
        fnames = []
        if features:
            try:
                fnames = [f.name() for f in features[0].fields()]
            except Exception:
                fnames = []

        for feature in features:
            try:
                attrs = feature.attributes()
                props = dict(zip(fnames, attrs)) if fnames else dict(zip([f.name() for f in feature.fields()], attrs))
            except Exception:
                props = {}

            def norm(v):
                if v is None:
                    return None
                s = str(v).strip()
                return s if s != "" else None

            p1 = norm(props.get(parent_field)) if parent_field else None
            p2 = norm(props.get(sub_field)) if sub_field else None
            p3 = norm(props.get(sub_sub_field)) if sub_sub_field else None

            path = []
            if p1:
                path.append(p1)
            if p2:
                path.append(p2)
            if p3:
                path.append(p3)

            # Insert into tree at correct depth (only non-empty fields become folders)
            node = tree
            for key in path:
                node = node.setdefault(key, {})
            node.setdefault("_features_", []).append({
                "properties": props,
                "geometry": feature.geometry(),
                "feature": feature
            })

        return tree

    def build_kml(self, grouped, doc_name, label_field, line_color, layer, selected_fields, use_layer_style):
        def build_node(node):
            xml = ""
            for feat in node.get("_features_", []):
                transformed = self.transform_geometry_to_wgs84(feat["geometry"], layer.crs())
                feat["geometry"] = transformed
                xml += self.create_placemark(feat, label_field, line_color, layer, selected_fields, use_layer_style)

            for key in sorted(k for k in node.keys() if k != "_features_"):
                sub = node[key]
                inner = build_node(sub)
                if inner.strip():
                    xml += f"<Folder><name>{self.safe(key)}</name>{inner}</Folder>"
            return xml

        top_xml = ""
        if isinstance(grouped, dict):
            for feat in grouped.get("_features_", []):
                transformed = self.transform_geometry_to_wgs84(feat["geometry"], layer.crs())
                feat["geometry"] = transformed
                top_xml += self.create_placemark(feat, label_field, line_color, layer, selected_fields, use_layer_style)

            for key in sorted(k for k in grouped.keys() if k != "_features_"):
                subnode = grouped[key]
                inner = build_node(subnode)
                if inner.strip():
                    top_xml += f"<Folder><name>{self.safe(key)}</name>{inner}</Folder>"

        kml_text = f"""<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
    <name>{self.safe(doc_name)}</name>
    {top_xml}
</Document>
</kml>
"""
        return kml_text

    def create_placemark(self, feat, label_field, line_color, layer, selected_fields, use_layer_style):
        props = feat["properties"]
        geom = feat["geometry"]
        feature = feat["feature"]

        name_value = props.get(label_field, None) if label_field else None
        name = self.safe(name_value) if name_value not in [None, ""] else "No Name"

        rows = []
        for i, field_name in enumerate(selected_fields):
            if field_name in props:
                value = props[field_name]
                if value is None:
                    value = ""
                bg = "#DDDDFF" if i % 2 == 0 else "transparent"
                rows.append(f'<tr style="background-color:{bg};"><td>{self.safe(field_name)}</td><td>{self.safe(value)}</td></tr>')

        table_html = f"""<table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif;">{''.join(rows)}</table>"""

        fragments = self.geom_to_kml_fragments(geom)
        if not fragments:
            return ""

        if use_layer_style:
            layer_color = self.get_layer_style_color(layer, feature)
            final_color = layer_color if layer_color else line_color
        else:
            final_color = line_color

        if len(fragments) == 1:
            geom_xml = fragments[0]
        else:
            geom_xml = "<MultiGeometry>" + "".join(fragments) + "</MultiGeometry>"

        style = self.get_geometry_style(geom, final_color)

        placemark = f"""<Placemark><name>{name}</name><description><![CDATA[{table_html}]]></description>{style}{geom_xml}</Placemark>"""
        return placemark

    def get_geometry_style(self, geometry, color):
        geom_type = geometry.type()
        if geom_type == QgsWkbTypes.PointGeometry:
            return f"<Style><IconStyle><color>{color}</color><scale>1.2</scale></IconStyle><LabelStyle><scale>0.8</scale></LabelStyle></Style>"
        elif geom_type == QgsWkbTypes.LineGeometry:
            return f"<Style><LineStyle><color>{color}</color><width>3</width></LineStyle></Style>"
        elif geom_type == QgsWkbTypes.PolygonGeometry:
            inner = color[2:] if len(color) >= 8 else color
            return f"<Style><LineStyle><color>{color}</color><width>2</width></LineStyle><PolyStyle><color>40{inner}</color></PolyStyle></Style>"
        else:
            return f"<Style><LineStyle><color>{color}</color><width>2</width></LineStyle></Style>"
