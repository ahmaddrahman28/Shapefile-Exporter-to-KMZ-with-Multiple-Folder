def classFactory(iface):
    from .kmz_exporter import KMZExporterPlugin
    return KMZExporterPlugin(iface)