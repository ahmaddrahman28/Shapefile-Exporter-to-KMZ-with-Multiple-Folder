"""
KMZ Exporter Plugin
Exports vector layers to KMZ format
"""

def classFactory(iface):
    """Load KMZExporterPlugin class from file kmz_exporter."""
    from .kmz_exporter import KMZExporterPlugin
    return KMZExporterPlugin(iface)