import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QPushButton, QLineEdit, QColorDialog,
    QGroupBox, QFormLayout, QCheckBox, QFileDialog,
    QListWidget, QListWidgetItem, QAbstractItemView
)
from qgis.PyQt.QtGui import QColor
from qgis.core import QgsProject, QgsWkbTypes


class ExportDialog(QDialog):
    def __init__(self, layer, parent=None):
        super().__init__(parent)
        self.layer = layer
        self.setWindowTitle("Export to KMZ")
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()

        # Layer info
        layer_group = QGroupBox("Layer Information")
        layer_layout = QFormLayout()
        layer_layout.addRow(QLabel("Layer:"), QLabel(self.layer.name()))
        layer_layout.addRow(QLabel("Features:"), QLabel(str(self.layer.featureCount())))

        # Geometry display using wkbType -> display string
        try:
            geom_display = QgsWkbTypes.displayString(self.layer.wkbType())
        except Exception:
            geom_display = "Unknown"
        layer_layout.addRow(QLabel("Geometry Type:"), QLabel(geom_display))

        # CRS info
        try:
            crs_obj = self.layer.crs()
            crs_info = f"{crs_obj.description()} ({crs_obj.authid()})"
        except Exception:
            crs_info = "Unknown"
        layer_layout.addRow(QLabel("CRS:"), QLabel(crs_info))

        # Warning if not WGS84
        try:
            if self.layer.crs().authid() != 'EPSG:4326':
                warning_label = QLabel(
                    "Note: Layer CRS is not WGS84 (EPSG:4326). Automatic transformation will be applied."
                )
                warning_label.setStyleSheet("color: orange; font-weight: bold;")
                layer_layout.addRow(warning_label)
        except Exception:
            pass

        layer_group.setLayout(layer_layout)
        layout.addWidget(layer_group)

        # Field selection for folder structure
        fields_group = QGroupBox("Folder Structure")
        fields_layout = QFormLayout()

        # Get field names
        try:
            field_names = [field.name() for field in self.layer.fields()]
        except Exception:
            field_names = []

        self.parent_combo = QComboBox()
        self.parent_combo.addItems([""] + field_names)

        self.sub_combo = QComboBox()
        self.sub_combo.addItems([""] + field_names)

        self.sub_sub_combo = QComboBox()
        self.sub_sub_combo.addItems([""] + field_names)

        self.label_combo = QComboBox()
        self.label_combo.addItems([""] + field_names)

        # Checkbox untuk skip folder kosong
        self.skip_empty_folders = QCheckBox("Skip empty folders (jika field NULL/kosong)")
        self.skip_empty_folders.setChecked(True)

        fields_layout.addRow("Parent Folder Field:", self.parent_combo)
        fields_layout.addRow("Sub Folder Field:", self.sub_combo)
        fields_layout.addRow("Sub-Sub Folder Field:", self.sub_sub_combo)
        fields_layout.addRow("Label Field:", self.label_combo)
        fields_layout.addRow("", self.skip_empty_folders)

        fields_group.setLayout(fields_layout)
        layout.addWidget(fields_group)

        # Attribute fields selection
        attr_group = QGroupBox("Attribute Display")
        attr_layout = QVBoxLayout()

        attr_help = QLabel("Select fields to display in KMZ attribute table:")
        attr_layout.addWidget(attr_help)

        self.fields_list = QListWidget()
        self.fields_list.setSelectionMode(QAbstractItemView.MultiSelection)

        # Add all fields to list
        for field_name in field_names:
            item = QListWidgetItem(field_name)
            self.fields_list.addItem(item)
            item.setSelected(True)  # Select all by default

        attr_layout.addWidget(self.fields_list)

        # Checkbox untuk menggunakan style layer
        self.use_layer_style = QCheckBox("Use layer style colors (for polygons/lines)")
        self.use_layer_style.setChecked(True)
        attr_layout.addWidget(self.use_layer_style)

        attr_group.setLayout(attr_layout)
        layout.addWidget(attr_group)

        # Output file
        output_group = QGroupBox("Output Settings")
        output_layout = QFormLayout()

        self.output_edit = QLineEdit()
        self.browse_btn = QPushButton("Browse...")

        output_hbox = QHBoxLayout()
        output_hbox.addWidget(self.output_edit)
        output_hbox.addWidget(self.browse_btn)

        self.color_edit = QLineEdit("ff0000ff")
        self.color_btn = QPushButton("Choose Color...")

        color_hbox = QHBoxLayout()
        color_hbox.addWidget(self.color_edit)
        color_hbox.addWidget(self.color_btn)

        output_layout.addRow("Output File:", output_hbox)
        output_layout.addRow("Default Color (AABBGGRR):", color_hbox)

        output_group.setLayout(output_layout)
        layout.addWidget(output_group)

        # Buttons
        button_layout = QHBoxLayout()
        self.ok_btn = QPushButton("Export")
        self.cancel_btn = QPushButton("Cancel")

        button_layout.addWidget(self.ok_btn)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)
        self.setLayout(layout)

        # Connections
        self.browse_btn.clicked.connect(self.browse_output)
        self.color_btn.clicked.connect(self.choose_color)
        self.ok_btn.clicked.connect(self.accept)
        self.cancel_btn.clicked.connect(self.reject)

        # Set default output path
        project_path = QgsProject.instance().fileName()
        if project_path:
            base_name = os.path.splitext(os.path.basename(project_path))[0]
            default_output = os.path.join(os.path.dirname(project_path), f"{base_name}.kmz")
            self.output_edit.setText(default_output)
        else:
            # Fallback jika project belum disimpan
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            default_output = os.path.join(desktop, f"{self.layer.name()}.kmz")
            self.output_edit.setText(default_output)

    def browse_output(self):
        filename, _ = QFileDialog.getSaveFileName(
            self, "Save KMZ File", self.output_edit.text(), "KMZ Files (*.kmz)"
        )
        if filename:
            if not filename.lower().endswith('.kmz'):
                filename += '.kmz'
            self.output_edit.setText(filename)

    def choose_color(self):
        color = QColorDialog.getColor(QColor(255, 0, 0), self)
        if color.isValid():
            # Convert to AABBGGRR format (alpha + blue + green + red)
            aabbggrr = f"{color.alpha():02x}{color.blue():02x}{color.green():02x}{color.red():02x}"
            self.color_edit.setText(aabbggrr)

    def get_parameters(self):
        selected_fields = []
        for i in range(self.fields_list.count()):
            if self.fields_list.item(i).isSelected():
                selected_fields.append(self.fields_list.item(i).text())

        return {
            'layer': self.layer,
            'output_file': self.output_edit.text(),
            'parent_field': self.parent_combo.currentText(),
            'sub_field': self.sub_combo.currentText(),
            'sub_sub_field': self.sub_sub_combo.currentText(),
            'label_field': self.label_combo.currentText(),
            'line_color': self.color_edit.text(),
            'skip_empty_folders': self.skip_empty_folders.isChecked(),
            'selected_fields': selected_fields,
            'use_layer_style': self.use_layer_style.isChecked()
        }
