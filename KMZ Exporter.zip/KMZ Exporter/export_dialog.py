import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QPushButton, QLineEdit,
    QGroupBox, QFormLayout, QCheckBox, QFileDialog,
    QListWidget, QListWidgetItem, QAbstractItemView,
    QColorDialog, QSpinBox, QDoubleSpinBox
)
from qgis.PyQt.QtGui import QColor, QPixmap, QIcon
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsProject, QgsWkbTypes


class ExportDialog(QDialog):
    def __init__(self, layer, parent=None):
        super().__init__(parent)
        self.layer = layer
        self.setWindowTitle("Export to KMZ")
        self.resize(600, 800)  # Ukuran dialog yang lebih baik
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()

        # Layer info
        layer_group = QGroupBox("Layer Information")
        layer_layout = QFormLayout()
        layer_layout.addRow(QLabel("Layer:"), QLabel(self.layer.name()))
        
        try:
            feature_count = str(self.layer.featureCount())
        except:
            feature_count = "Unknown"
        layer_layout.addRow(QLabel("Features:"), QLabel(feature_count))

        try:
            geom_display = QgsWkbTypes.displayString(self.layer.wkbType())
        except Exception:
            geom_display = "Unknown"
        layer_layout.addRow(QLabel("Geometry Type:"), QLabel(geom_display))

        try:
            crs_obj = self.layer.crs()
            crs_info = f"{crs_obj.description()} ({crs_obj.authid()})"
        except Exception:
            crs_info = "Unknown"
        layer_layout.addRow(QLabel("CRS:"), QLabel(crs_info))

        # Warning untuk CRS bukan WGS84
        try:
            if self.layer.crs().authid() != 'EPSG:4326':
                warning_label = QLabel(
                    "⚠ Note: Layer CRS is not WGS84 (EPSG:4326). Automatic transformation will be applied."
                )
                warning_label.setStyleSheet("color: orange; font-weight: bold;")
                layer_layout.addRow(warning_label)
        except Exception:
            pass

        layer_group.setLayout(layer_layout)
        layout.addWidget(layer_group)

        # Field selection for folder structure
        fields_group = QGroupBox("Folder Structure")
        fields_layout = QFormLayout()

        try:
            field_names = [field.name() for field in self.layer.fields()]
        except Exception:
            field_names = []

        self.parent_combo = QComboBox()
        self.parent_combo.addItems([""] + field_names)

        self.sub_combo = QComboBox()
        self.sub_combo.addItems([""] + field_names)

        self.sub_sub_combo = QComboBox()
        self.sub_sub_combo.addItems([""] + field_names)

        self.label_combo = QComboBox()
        self.label_combo.addItems([""] + field_names)

        self.skip_empty_folders = QCheckBox("Skip empty folders (if field is NULL/empty)")
        self.skip_empty_folders.setChecked(True)

        fields_layout.addRow("Parent Folder Field:", self.parent_combo)
        fields_layout.addRow("Sub Folder Field:", self.sub_combo)
        fields_layout.addRow("Sub-Sub Folder Field:", self.sub_sub_combo)
        fields_layout.addRow("Label Field:", self.label_combo)
        fields_layout.addRow("", self.skip_empty_folders)

        fields_group.setLayout(fields_layout)
        layout.addWidget(fields_group)

        # Attribute fields selection
        attr_group = QGroupBox("Attribute Display")
        attr_layout = QVBoxLayout()

        attr_help = QLabel("Select fields to display in KMZ attribute table:")
        attr_layout.addWidget(attr_help)

        self.fields_list = QListWidget()
        self.fields_list.setSelectionMode(QAbstractItemView.MultiSelection)

        for field_name in field_names:
            item = QListWidgetItem(field_name)
            self.fields_list.addItem(item)
            item.setSelected(True)

        attr_layout.addWidget(self.fields_list)

        self.use_layer_style = QCheckBox("Use layer style colors")
        self.use_layer_style.setChecked(True)
        self.use_layer_style.toggled.connect(self.on_style_checkbox_changed)
        attr_layout.addWidget(self.use_layer_style)

        attr_group.setLayout(attr_layout)
        layout.addWidget(attr_group)

        # Custom Style Settings
        style_group = QGroupBox("Custom Style Settings")
        style_layout = QFormLayout()
        
        # Color picker untuk line/polygon border
        self.line_color_btn = QPushButton()
        self.line_color_btn.setFixedSize(50, 25)
        self.line_color = QColor(0, 0, 255)  # Default blue
        self.update_color_button()
        self.line_color_btn.clicked.connect(self.choose_line_color)
        
        # Stroke width
        self.stroke_width_spin = QDoubleSpinBox()
        self.stroke_width_spin.setRange(0.5, 10.0)
        self.stroke_width_spin.setValue(2.0)
        self.stroke_width_spin.setSingleStep(0.5)
        self.stroke_width_spin.setSuffix(" px")
        
        # Fill color untuk polygon
        self.fill_color_btn = QPushButton()
        self.fill_color_btn.setFixedSize(50, 25)
        self.fill_color = QColor(255, 0, 0, 102)  # Red dengan 40% opacity
        self.update_fill_color_button()
        self.fill_color_btn.clicked.connect(self.choose_fill_color)
        
        # Fill opacity
        self.fill_opacity_spin = QSpinBox()
        self.fill_opacity_spin.setRange(0, 100)
        self.fill_opacity_spin.setValue(40)
        self.fill_opacity_spin.setSuffix("%")
        self.fill_opacity_spin.valueChanged.connect(self.update_fill_color_opacity)
        
        style_layout.addRow("Line/Border Color:", self.line_color_btn)
        style_layout.addRow("Stroke Width:", self.stroke_width_spin)
        style_layout.addRow("Fill Color:", self.fill_color_btn)
        style_layout.addRow("Fill Opacity:", self.fill_opacity_spin)
        
        style_group.setLayout(style_layout)
        style_group.setEnabled(False)
        self.style_group = style_group
        layout.addWidget(style_group)

        # Output file
        output_group = QGroupBox("Output Settings")
        output_layout = QFormLayout()

        self.output_edit = QLineEdit()
        self.browse_btn = QPushButton("Browse...")

        output_hbox = QHBoxLayout()
        output_hbox.addWidget(self.output_edit)
        output_hbox.addWidget(self.browse_btn)

        info_label = QLabel("Note: Colors will be taken from layer style OR custom settings above.")
        info_label.setStyleSheet("color: green; font-style: italic;")
        output_layout.addRow(info_label)
        output_layout.addRow("Output File:", output_hbox)

        output_group.setLayout(output_layout)
        layout.addWidget(output_group)

        # Buttons
        button_layout = QHBoxLayout()
        self.ok_btn = QPushButton("Export")
        self.cancel_btn = QPushButton("Cancel")

        button_layout.addWidget(self.ok_btn)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)
        self.setLayout(layout)

        # Connections
        self.browse_btn.clicked.connect(self.browse_output)
        self.ok_btn.clicked.connect(self.accept)
        self.cancel_btn.clicked.connect(self.reject)

        # Set default output path
        self.set_default_output_path()

    def set_default_output_path(self):
        """Set default output path"""
        project_path = QgsProject.instance().fileName()
        if project_path:
            base_name = os.path.splitext(os.path.basename(project_path))[0]
            default_output = os.path.join(
                os.path.dirname(project_path), 
                f"{base_name}_{self.layer.name()}.kmz"
            )
        else:
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            default_output = os.path.join(desktop, f"{self.layer.name()}.kmz")
        
        self.output_edit.setText(default_output)

    def on_style_checkbox_changed(self, checked):
        """Enable/disable custom style settings based on checkbox"""
        self.style_group.setEnabled(not checked)
    
    def update_color_button(self):
        """Update line color button appearance"""
        pixmap = QPixmap(50, 25)
        pixmap.fill(self.line_color)
        icon = QIcon(pixmap)
        self.line_color_btn.setIcon(icon)
        self.line_color_btn.setIconSize(pixmap.size())
    
    def update_fill_color_button(self):
        """Update fill color button appearance"""
        pixmap = QPixmap(50, 25)
        pixmap.fill(self.fill_color)
        icon = QIcon(pixmap)
        self.fill_color_btn.setIcon(icon)
        self.fill_color_btn.setIconSize(pixmap.size())
    
    def update_fill_color_opacity(self, value):
        """Update fill color opacity"""
        self.fill_color.setAlpha(int(value * 255 / 100))
        self.update_fill_color_button()
    
    def choose_line_color(self):
        """Open color dialog for line color"""
        color = QColorDialog.getColor(self.line_color, self, "Select Line/Border Color")
        if color.isValid():
            self.line_color = color
            self.update_color_button()
    
    def choose_fill_color(self):
        """Open color dialog for fill color"""
        color = QColorDialog.getColor(self.fill_color, self, "Select Fill Color")
        if color.isValid():
            # Pertahankan opacity yang sudah ada
            current_alpha = self.fill_color.alpha()
            self.fill_color = color
            self.fill_color.setAlpha(current_alpha)
            self.update_fill_color_button()

    def browse_output(self):
        """Browse for output file"""
        filename, _ = QFileDialog.getSaveFileName(
            self, 
            "Save KMZ File", 
            self.output_edit.text(), 
            "KMZ Files (*.kmz);;All Files (*)"
        )
        if filename:
            if not filename.lower().endswith('.kmz'):
                filename += '.kmz'
            self.output_edit.setText(filename)

    def get_parameters(self):
        """Get all export parameters"""
        selected_fields = []
        for i in range(self.fields_list.count()):
            if self.fields_list.item(i).isSelected():
                selected_fields.append(self.fields_list.item(i).text())

        return {
            'layer': self.layer,
            'output_file': self.output_edit.text(),
            'parent_field': self.parent_combo.currentText(),
            'sub_field': self.sub_combo.currentText(),
            'sub_sub_field': self.sub_sub_combo.currentText(),
            'label_field': self.label_combo.currentText(),
            'skip_empty_folders': self.skip_empty_folders.isChecked(),
            'selected_fields': selected_fields,
            'use_layer_style': self.use_layer_style.isChecked(),
            'custom_line_color': self.line_color,
            'custom_stroke_width': self.stroke_width_spin.value(),
            'custom_fill_color': self.fill_color,
            'custom_fill_opacity': self.fill_opacity_spin.value()
        }