# KMZ Exporter for QGIS

A QGIS plugin to export vector layers to KMZ format with advanced features:

## Features:
- Export with folder structure (up to 3 levels)
- Use QGIS layer styles or custom styles
- Attribute table display in KMZ
- Support for points, lines, and polygons
- CRS transformation to WGS84 (EPSG:4326)
- Skip empty folders option

## Installation:
1. Download the plugin files
2. Copy to QGIS plugins folder: `C:\Users\[Username]\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
3. Restart QGIS or enable from Plugins > Manage and Install Plugins

## Usage:
1. Select a vector layer in QGIS
2. Click the "Export to KMZ" button in the toolbar
3. Configure export options
4. Click Export

## Requirements:
- QGIS 3.0 or higher
- simplekml library